import { db } from "@/db";
import { savedProjects } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import type { StartupForm } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select()
      .from(savedProjects)
      .orderBy(desc(savedProjects.isPinned), desc(savedProjects.updatedAt))
      .limit(50);
    return Response.json({ ok: true, projects: rows });
  } catch {
    return Response.json({ ok: true, projects: [] });
  }
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { name: string; formData: StartupForm };
    if (!body.name?.trim()) {
      return Response.json({ ok: false, error: "Project name is required." }, { status: 400 });
    }
    const [row] = await db
      .insert(savedProjects)
      .values({
        name: body.name.trim(),
        formData: body.formData as unknown as Record<string, string>,
      })
      .returning();
    return Response.json({ ok: true, project: row });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}
