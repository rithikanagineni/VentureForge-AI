import { db } from "@/db";
import { savedProjects } from "@/db/schema";
import { eq } from "drizzle-orm";
import type { StartupForm } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const body = (await req.json()) as { name?: string; formData?: StartupForm; isPinned?: boolean };
    await db
      .update(savedProjects)
      .set({
        ...(body.name !== undefined ? { name: body.name } : {}),
        ...(body.formData !== undefined
          ? { formData: body.formData as unknown as Record<string, string> }
          : {}),
        ...(body.isPinned !== undefined ? { isPinned: body.isPinned } : {}),
        updatedAt: new Date(),
      })
      .where(eq(savedProjects.id, Number(id)));
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    await db.delete(savedProjects).where(eq(savedProjects.id, Number(id)));
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}
