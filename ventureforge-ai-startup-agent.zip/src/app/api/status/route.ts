import { graniteConfigured } from "@/lib/watsonx";

export const dynamic = "force-dynamic";

/** Reports whether live IBM Granite credentials are configured. */
export async function GET() {
  return Response.json({
    ok: true,
    graniteLive: graniteConfigured(),
    model: process.env.WATSONX_MODEL_ID || "ibm/granite-3-8b-instruct",
  });
}
