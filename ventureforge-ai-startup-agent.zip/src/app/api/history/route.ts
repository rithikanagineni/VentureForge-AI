import { db } from "@/db";
import { generations } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** GET /api/history — return recent generations (optionally by session). */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const sessionId = searchParams.get("sessionId");

    const rows = sessionId
      ? await db
          .select()
          .from(generations)
          .where(eq(generations.sessionId, sessionId))
          .orderBy(desc(generations.createdAt))
          .limit(100)
      : await db
          .select()
          .from(generations)
          .orderBy(desc(generations.createdAt))
          .limit(100);

    return Response.json({ ok: true, items: rows });
  } catch {
    return Response.json({ ok: true, items: [] });
  }
}

/** DELETE /api/history?sessionId=... — clear history for a session (or all). */
export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const sessionId = searchParams.get("sessionId");
    if (sessionId) {
      await db.delete(generations).where(eq(generations.sessionId, sessionId));
    } else {
      await db.delete(generations);
    }
    return Response.json({ ok: true });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to clear history.";
    return Response.json({ ok: false, error: message }, { status: 500 });
  }
}
