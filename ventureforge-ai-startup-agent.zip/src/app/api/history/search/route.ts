import { db } from "@/db";
import { generations } from "@/db/schema";
import { desc, ilike, or } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** GET /api/history/search?q=... — full-text search across title and prompt */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const q = (searchParams.get("q") || "").trim();
    if (!q) return Response.json({ ok: true, items: [] });

    const rows = await db
      .select()
      .from(generations)
      .where(
        or(
          ilike(generations.title, `%${q}%`),
          ilike(generations.prompt, `%${q}%`),
          ilike(generations.agentName, `%${q}%`),
        ),
      )
      .orderBy(desc(generations.createdAt))
      .limit(40);

    return Response.json({ ok: true, items: rows });
  } catch {
    return Response.json({ ok: true, items: [] });
  }
}
