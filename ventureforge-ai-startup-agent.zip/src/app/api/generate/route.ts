import { db } from "@/db";
import { generations } from "@/db/schema";
import {
  AGENT_MAP,
  GENERAL_AGENT,
  HEALTH_SCORE_AGENT,
  INVESTOR_DECISION_AGENT,
  PITCH_DECK_AGENT,
  buildPrompt,
  detectIntent,
} from "@/lib/agents";
import { generateBlueprint } from "@/lib/watsonx";
import {
  EMPTY_FORM,
  type GenerateRequest,
  type HealthScoreResult,
  type InvestorDecisionResult,
  type PitchDeckResult,
  type StartupForm,
} from "@/lib/types";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: Request) {
  let body: GenerateRequest;
  try {
    body = (await req.json()) as GenerateRequest;
  } catch {
    return Response.json(
      { ok: false, error: "Invalid request body." },
      { status: 400 },
    );
  }

  const prompt = (body.prompt || "").trim();
  const form: StartupForm = { ...EMPTY_FORM, ...(body.form || {}) };
  const sessionId = body.sessionId || "default";

  // Determine which agent handles this request.
  let agentId = body.agentId;
  if (!agentId || agentId === "copilot") {
    agentId = detectIntent(prompt);
  }
  const specialAgents: Record<string, typeof HEALTH_SCORE_AGENT> = {
    startup_health: HEALTH_SCORE_AGENT,
    investor_decision: INVESTOR_DECISION_AGENT,
    pitch_deck: PITCH_DECK_AGENT,
  };
  const agent =
    specialAgents[agentId] ??
    (agentId === "copilot" ? GENERAL_AGENT : (AGENT_MAP[agentId] || GENERAL_AGENT) as typeof HEALTH_SCORE_AGENT);

  // Empty prompt validation — allow if a specific agent + form context exists.
  const hasContext =
    Boolean(prompt) ||
    Object.values(form).some((v) => v && v.trim().length > 0);
  if (!hasContext) {
    return Response.json(
      {
        ok: false,
        error:
          "Please describe your startup or fill in the form before generating.",
      },
      { status: 400 },
    );
  }

  try {
    const fullPrompt = buildPrompt(agent, prompt, form);
    const result = await generateBlueprint(agent, prompt, form, fullPrompt);

    const title =
      (prompt && prompt.slice(0, 60)) ||
      `${agent.name}${form.startupName ? ` · ${form.startupName}` : ""}`;

    // Persist to history (non-fatal if it fails).
    try {
      await db.insert(generations).values({
        sessionId,
        agentId: agent.id,
        agentName: agent.name,
        title,
        prompt: prompt || agent.name,
        formData: form as unknown as Record<string, string>,
        output: result.text,
        mode: result.mode,
      });
    } catch {
      // ignore persistence errors — the user still gets their result
    }

    // Parse JSON for structured-output agents
    const parseJson = <T,>(raw: string): T | undefined => {
      try {
        const clean = raw.replace(/```json|```/g, "").trim();
        const match = clean.match(/\{[\s\S]*\}/);
        return match ? (JSON.parse(match[0]) as T) : undefined;
      } catch { return undefined; }
    };

    const healthData = agent.id === "startup_health"
      ? parseJson<HealthScoreResult>(result.text)
      : undefined;
    const investorData = agent.id === "investor_decision"
      ? parseJson<InvestorDecisionResult>(result.text)
      : undefined;
    const pitchData = agent.id === "pitch_deck"
      ? parseJson<PitchDeckResult>(result.text)
      : undefined;

    return Response.json({
      ok: true,
      output: result.text,
      agentId: agent.id,
      agentName: agent.name,
      title,
      mode: result.mode,
      ...(healthData ? { healthData } : {}),
      ...(investorData ? { investorData } : {}),
      ...(pitchData ? { pitchData } : {}),
    });
  } catch (err) {
    const message =
      err instanceof Error ? err.message : "Unexpected error generating output.";
    return Response.json({ ok: false, error: message }, { status: 500 });
  }
}
