import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "VentureForge AI — Your AI Startup Copilot",
  description:
    "Turn raw startup ideas into complete, actionable blueprints with IBM Granite on watsonx.ai.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/* Apply saved theme / accent before first paint to prevent flash */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              try {
                var theme = localStorage.getItem('vf-theme') || 'light';
                var accent = localStorage.getItem('vf-accent') || 'violet';
                document.documentElement.dataset.theme = theme;
                document.documentElement.dataset.accent = accent;
              } catch(e) {}
            `,
          }}
        />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
