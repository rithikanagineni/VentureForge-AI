"use client";

import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

/** Styled markdown renderer with GitHub-flavoured markdown (tables, etc.). */
export default function Markdown({ content }: { content: string }) {
  return (
    <div className="vf-prose">
      <ReactMarkdown remarkPlugins={[remarkGfm]}>{content}</ReactMarkdown>
    </div>
  );
}
