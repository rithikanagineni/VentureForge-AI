"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { HistoryItem, SavedProject, StartupForm } from "@/lib/types";
import { AGENT_MAP, GENERAL_AGENT } from "@/lib/agents";

export type ViewId = "dashboard" | "copilot" | "about" | "settings";

const NAV: Array<{ id: ViewId; label: string; icon: string }> = [
  { id: "dashboard", label: "Dashboard", icon: "▦" },
  { id: "copilot", label: "AI Copilot", icon: "✦" },
  { id: "about", label: "About", icon: "◉" },
  { id: "settings", label: "Settings", icon: "⚙" },
];

export default function Sidebar({
  active,
  onNavigate,
  open,
  onClose,
  onLoadHistoryItem,
  onLoadProject,
  currentForm,
}: {
  active: ViewId;
  onNavigate: (v: ViewId) => void;
  open: boolean;
  onClose: () => void;
  onLoadHistoryItem: (item: HistoryItem) => void;
  onLoadProject: (p: SavedProject) => void;
  currentForm: StartupForm;
}) {
  const [tab, setTab] = useState<"nav" | "history" | "projects">("nav");
  const [historySearch, setHistorySearch] = useState("");
  const [agentFilter, setAgentFilter] = useState("all");
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [projects, setProjects] = useState<SavedProject[]>([]);
  const [saveProjectName, setSaveProjectName] = useState("");
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState("");
  const searchTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  const loadHistory = useCallback(async () => {
    try {
      const res = await fetch("/api/history");
      const data = await res.json();
      if (data.ok) setHistory(data.items as HistoryItem[]);
    } catch { /* ignore */ }
  }, []);

  const loadProjects = useCallback(async () => {
    try {
      const res = await fetch("/api/projects");
      const data = await res.json();
      if (data.ok) setProjects(data.projects as SavedProject[]);
    } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    loadHistory();
    loadProjects();
  }, [loadHistory, loadProjects]);

  // debounced search
  useEffect(() => {
    if (searchTimeout.current) clearTimeout(searchTimeout.current);
    if (!historySearch.trim()) { loadHistory(); return; }
    searchTimeout.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/history/search?q=${encodeURIComponent(historySearch)}`);
        const data = await res.json();
        if (data.ok) setHistory(data.items as HistoryItem[]);
      } catch { /* ignore */ }
    }, 350);
    return () => { if (searchTimeout.current) clearTimeout(searchTimeout.current); };
  }, [historySearch, loadHistory]);

  const saveProject = async () => {
    if (!saveProjectName.trim()) { setSaveMsg("Enter a project name first."); return; }
    setSaving(true); setSaveMsg("");
    try {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: saveProjectName.trim(), formData: currentForm }),
      });
      const data = await res.json();
      if (data.ok) {
        setSaveMsg("Project saved!");
        setSaveProjectName("");
        loadProjects();
      } else { setSaveMsg(data.error || "Failed."); }
    } catch { setSaveMsg("Network error."); }
    finally { setSaving(false); setTimeout(() => setSaveMsg(""), 2000); }
  };

  const deleteProject = async (id: number) => {
    await fetch(`/api/projects/${id}`, { method: "DELETE" });
    loadProjects();
  };

  const togglePin = async (p: SavedProject) => {
    await fetch(`/api/projects/${p.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isPinned: !p.isPinned }),
    });
    loadProjects();
  };

  const filteredHistory = agentFilter === "all"
    ? history
    : history.filter((h) => h.agentId === agentFilter);

  const uniqueAgents = Array.from(new Set(history.map((h) => h.agentId)));

  return (
    <>
      {open && (
        <button
          aria-label="Close navigation"
          className="fixed inset-0 z-30 bg-slate-900/20 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-72 flex-col border-r border-white/70 bg-white/80 shadow-[20px_0_60px_-35px_rgba(79,70,229,.22)] backdrop-blur-2xl transition-transform duration-300 lg:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`}
      >
        {/* Logo */}
        <div className="flex shrink-0 items-center gap-3 border-b border-slate-100 px-5 py-5">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-500 text-lg font-extrabold text-white shadow-lg shadow-violet-200">
            V
          </div>
          <div className="leading-tight">
            <div className="text-[15px] font-extrabold vf-gradient-text">VentureForge AI</div>
            <div className="text-[10px] font-semibold text-slate-400 tracking-wide">Your AI Startup Copilot</div>
          </div>
        </div>

        {/* Tab bar */}
        <div className="flex shrink-0 border-b border-slate-100">
          {(["nav","history","projects"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-2.5 text-[11px] font-bold uppercase tracking-wide transition ${tab === t ? "border-b-2 border-indigo-600 text-indigo-600" : "text-slate-400 hover:text-slate-600"}`}
            >
              {t === "nav" ? "Menu" : t === "history" ? "History" : "Projects"}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto">
          {/* NAV tab */}
          {tab === "nav" && (
            <nav className="space-y-1 px-3 py-4">
              {NAV.map((item) => {
                const isActive = active === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => { onNavigate(item.id); onClose(); }}
                    className={`flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition-all ${isActive ? "bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-md shadow-indigo-100" : "text-slate-600 hover:bg-slate-100 hover:text-indigo-700"}`}
                  >
                    <span className="text-base">{item.icon}</span>
                    {item.label}
                  </button>
                );
              })}
            </nav>
          )}

          {/* HISTORY tab */}
          {tab === "history" && (
            <div className="flex flex-col gap-3 p-3">
              <input
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                placeholder="Search reports…"
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-700 placeholder-slate-400 outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100"
              />
              {uniqueAgents.length > 0 && (
                <select
                  value={agentFilter}
                  onChange={(e) => setAgentFilter(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-700 outline-none focus:border-indigo-400"
                >
                  <option value="all">All agents</option>
                  {uniqueAgents.map((id) => {
                    const a = id === "copilot" ? GENERAL_AGENT : AGENT_MAP[id];
                    return a ? <option key={id} value={id}>{a.icon} {a.name}</option> : null;
                  })}
                </select>
              )}
              {filteredHistory.length === 0 ? (
                <p className="py-6 text-center text-xs text-slate-400">No reports found.</p>
              ) : (
                <div className="space-y-1.5">
                  {filteredHistory.slice(0, 30).map((h) => {
                    const a = h.agentId === "copilot" ? GENERAL_AGENT : AGENT_MAP[h.agentId];
                    return (
                      <button
                        key={h.id}
                        onClick={() => { onLoadHistoryItem(h); onClose(); }}
                        className="w-full rounded-xl border border-slate-100 bg-white px-3 py-2.5 text-left shadow-sm transition hover:border-indigo-200 hover:bg-indigo-50"
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-base">{a?.icon ?? "📄"}</span>
                          <span className="truncate text-xs font-bold text-slate-800">{h.title}</span>
                        </div>
                        <div className="mt-0.5 text-[10px] text-slate-400">
                          {new Date(h.createdAt).toLocaleDateString()} · {h.agentName}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* PROJECTS tab */}
          {tab === "projects" && (
            <div className="flex flex-col gap-3 p-3">
              <div className="rounded-2xl border border-indigo-100 bg-indigo-50 p-3">
                <p className="mb-2 text-[11px] font-bold text-indigo-700">Save current startup profile</p>
                <input
                  value={saveProjectName}
                  onChange={(e) => setSaveProjectName(e.target.value)}
                  placeholder="Project name…"
                  className="w-full rounded-xl border border-indigo-200 bg-white px-3 py-2 text-xs text-slate-800 placeholder-slate-400 outline-none focus:border-indigo-500"
                  onKeyDown={(e) => { if (e.key === "Enter") saveProject(); }}
                />
                <button
                  onClick={saveProject}
                  disabled={saving}
                  className="mt-2 w-full rounded-xl bg-indigo-600 py-2 text-xs font-bold text-white transition hover:bg-indigo-700 disabled:opacity-50"
                >
                  {saving ? "Saving…" : "Save Project"}
                </button>
                {saveMsg && <p className="mt-1.5 text-[10px] font-semibold text-indigo-600">{saveMsg}</p>}
              </div>

              {projects.length === 0 ? (
                <p className="py-4 text-center text-xs text-slate-400">No saved projects yet.</p>
              ) : (
                <div className="space-y-1.5">
                  {projects.map((p) => (
                    <div key={p.id} className="group rounded-xl border border-slate-100 bg-white p-3 shadow-sm">
                      <div className="flex items-start justify-between gap-2">
                        <button
                          onClick={() => { onLoadProject(p); setTab("nav"); onClose(); }}
                          className="flex-1 text-left"
                        >
                          <div className="text-xs font-bold text-slate-800">{p.name}</div>
                          <div className="mt-0.5 text-[10px] text-slate-400">
                            {(p.formData as Record<string,string>)?.industry || "Startup"} · {(p.formData as Record<string,string>)?.country || ""}
                          </div>
                        </button>
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => togglePin(p)} title={p.isPinned ? "Unpin" : "Pin"} className="rounded-lg p-1 text-xs hover:bg-slate-100">
                            {p.isPinned ? "★" : "☆"}
                          </button>
                          <button onClick={() => deleteProject(p.id)} className="rounded-lg p-1 text-xs text-rose-500 hover:bg-rose-50">✕</button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </aside>
    </>
  );
}
