"use client";

import type { HealthScoreResult } from "@/lib/types";

function ScoreBar({ score, color }: { score: number; color: string }) {
  return (
    <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-100">
      <div
        className={`h-full rounded-full bg-gradient-to-r ${color} transition-all duration-700`}
        style={{ width: `${score}%` }}
      />
    </div>
  );
}

function scoreColor(s: number) {
  if (s >= 80) return "from-emerald-400 to-teal-500";
  if (s >= 60) return "from-amber-400 to-orange-400";
  return "from-rose-400 to-red-400";
}

function gaugeColor(s: number) {
  if (s >= 80) return "#10b981";
  if (s >= 60) return "#f59e0b";
  return "#f43f5e";
}

function CircularGauge({ score }: { score: number }) {
  const r = 52;
  const circ = 2 * Math.PI * r;
  const dash = (score / 100) * circ;
  const col = gaugeColor(score);
  return (
    <div className="relative flex items-center justify-center">
      <svg width="130" height="130" viewBox="0 0 130 130">
        <circle cx="65" cy="65" r={r} fill="none" stroke="#e2e8f0" strokeWidth="13" />
        <circle
          cx="65" cy="65" r={r} fill="none"
          stroke={col} strokeWidth="13"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${circ}`}
          transform="rotate(-90 65 65)"
          className="transition-all duration-1000"
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="text-3xl font-extrabold" style={{ color: col }}>{score}</span>
        <span className="text-[10px] font-bold text-slate-400">/100</span>
      </div>
    </div>
  );
}

export default function HealthScoreCard({ result }: { result: HealthScoreResult }) {
  return (
    <article className="vf-card vf-fade-up overflow-hidden">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-3 border-b border-slate-100 px-6 py-4">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl text-xl"
          style={{ background: "linear-gradient(135deg,#fff1f2,#fce7f3)" }}>
          🏥
        </span>
        <div>
          <div className="text-sm font-extrabold text-slate-900">Startup Health Score Agent</div>
          <div className="text-xs text-slate-500">8-dimension assessment by IBM Granite</div>
        </div>
        <span className="ml-auto rounded-full bg-emerald-100 px-2.5 py-1 text-[10px] font-bold uppercase text-emerald-700">
          IBM Granite
        </span>
      </div>

      <div className="px-6 py-6">
        {/* Top: gauge + summary */}
        <div className="flex flex-wrap items-center gap-8">
          <CircularGauge score={result.overall_score} />
          <div className="min-w-0 flex-1">
            <span className={`inline-block rounded-full px-3 py-1 text-xs font-extrabold text-white mb-3 ${
              result.overall_score >= 80 ? "bg-emerald-500" :
              result.overall_score >= 60 ? "bg-amber-500" : "bg-rose-500"
            }`}>
              {result.grade}
            </span>
            <p className="text-sm leading-6 text-slate-600">{result.summary}</p>
          </div>
        </div>

        {/* Dimension bars */}
        <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
          {result.dimensions.map((d) => (
            <div key={d.name} className="rounded-2xl border border-slate-100 bg-slate-50 p-4">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-extrabold text-slate-700">{d.name}</span>
                <span className="text-xs font-extrabold" style={{ color: gaugeColor(d.score) }}>
                  {d.score}
                </span>
              </div>
              <div className="mt-2 flex items-center gap-2">
                <ScoreBar score={d.score} color={scoreColor(d.score)} />
              </div>
              <p className="mt-1.5 text-[11px] text-slate-500">{d.note}</p>
            </div>
          ))}
        </div>

        {/* Strengths / Risks / Actions */}
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {[
            { title: "💪 Top Strengths", items: result.top_strengths, bg: "bg-emerald-50 border-emerald-200", text: "text-emerald-800", tag: "bg-emerald-100 text-emerald-700" },
            { title: "⚠️ Critical Risks", items: result.critical_risks, bg: "bg-rose-50 border-rose-200", text: "text-rose-800", tag: "bg-rose-100 text-rose-700" },
            { title: "🎯 Next Actions", items: result.next_actions, bg: "bg-indigo-50 border-indigo-200", text: "text-indigo-800", tag: "bg-indigo-100 text-indigo-700" },
          ].map(({ title, items, bg, text, tag }) => (
            <div key={title} className={`rounded-2xl border p-4 ${bg}`}>
              <div className={`mb-3 inline-block rounded-full px-2.5 py-0.5 text-[10px] font-extrabold ${tag}`}>
                {title}
              </div>
              <ul className="space-y-2">
                {items.map((item, i) => (
                  <li key={i} className={`flex items-start gap-2 text-xs font-medium leading-5 ${text}`}>
                    <span className="mt-0.5 shrink-0 text-[10px]">▶</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </article>
  );
}
