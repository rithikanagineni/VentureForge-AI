"use client";

import { AGENTS } from "@/lib/agents";

const SPECIAL_AGENTS = [
  { id: "startup_health", name: "🏥 Health Score", gradient: "from-rose-400 to-pink-500" },
  { id: "investor_decision", name: "💼 Investor Simulator", gradient: "from-lime-500 to-green-600" },
  { id: "pitch_deck", name: "📈 Pitch Deck", gradient: "from-sky-500 to-blue-600" },
];

export default function QuickActions({ onSelect, disabled }: { onSelect: (id: string) => void; disabled?: boolean }) {
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
      {SPECIAL_AGENTS.map((a) => (
        <button
          key={a.id}
          disabled={disabled}
          onClick={() => onSelect(a.id)}
          className="group flex items-center gap-2 rounded-2xl border border-indigo-200 bg-gradient-to-r from-indigo-50 to-violet-50 px-3 py-2.5 text-xs font-bold text-indigo-700 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md disabled:cursor-not-allowed disabled:opacity-40"
        >
          {a.name}
        </button>
      ))}
      {AGENTS.map((agent) => (
        <button
          key={agent.id}
          disabled={disabled}
          onClick={() => onSelect(agent.id)}
          className="group flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 py-2.5 text-xs font-bold text-slate-600 shadow-sm transition hover:-translate-y-0.5 hover:border-indigo-200 hover:text-indigo-700 hover:shadow-md disabled:cursor-not-allowed disabled:opacity-40"
        >
          <span className={`inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br ${agent.gradient} text-sm`}>
            {agent.icon}
          </span>
          <span className="leading-tight truncate">{agent.name.replace(" Agent", "")}</span>
        </button>
      ))}
    </div>
  );
}
