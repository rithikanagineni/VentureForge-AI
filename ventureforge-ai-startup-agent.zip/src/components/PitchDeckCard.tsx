"use client";

import { useState } from "react";
import type { PitchDeckResult } from "@/lib/types";

const slideColors: Record<string, string> = {
  Hook: "from-violet-500 to-purple-600",
  Problem: "from-rose-500 to-pink-500",
  Solution: "from-emerald-500 to-teal-500",
  "Market Size": "from-sky-500 to-blue-500",
  Product: "from-indigo-500 to-violet-500",
  "Business Model": "from-amber-400 to-orange-500",
  Traction: "from-lime-400 to-green-500",
  Team: "from-cyan-500 to-teal-500",
  "The Ask": "from-fuchsia-500 to-pink-500",
  ThankYou: "from-slate-500 to-slate-600",
};

function slideColor(title: string) {
  const key = Object.keys(slideColors).find((k) => title.toLowerCase().includes(k.toLowerCase()));
  return key ? slideColors[key] : "from-slate-400 to-slate-500";
}

export default function PitchDeckCard({ result }: { result: PitchDeckResult }) {
  const [activeSlide, setActiveSlide] = useState(0);

  const downloadMarkdown = () => {
    const lines = [
      `# ${result.deck_title}`,
      `> ${result.tagline}`,
      ``,
      ...result.slides.flatMap((s) => [
        `---\n## Slide ${s.number}: ${s.title}\n`,
        ...s.content.map((b) => `- ${b}`),
        `\n**Speaker notes:** ${s.speaker_notes}\n`,
        `**Visual:** ${s.visual_suggestion}\n`,
      ]),
    ].join("\n");
    const blob = new Blob([lines], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "pitch-deck.md"; a.click(); URL.revokeObjectURL(url);
  };

  return (
    <article className="vf-card vf-fade-up overflow-hidden">
      <div className="flex flex-wrap items-center gap-3 border-b border-slate-100 px-6 py-4">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-sky-100 to-blue-100 text-xl">📈</span>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-extrabold text-slate-900">Pitch Deck Generator</div>
          <div className="truncate text-xs text-slate-500">{result.deck_title} · "{result.tagline}"</div>
        </div>
        <button onClick={downloadMarkdown} className="vf-secondary-button" title="Download deck as Markdown">
          ↓ MD
        </button>
        <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-[10px] font-bold uppercase text-emerald-700">IBM Granite</span>
      </div>

      <div className="flex flex-col lg:flex-row">
        {/* Slide navigator */}
        <div className="border-r border-slate-100 p-4 lg:w-44 shrink-0 overflow-y-auto" style={{ maxHeight: 560 }}>
          <div className="space-y-1">
            {result.slides.map((s, i) => (
              <button
                key={i}
                onClick={() => setActiveSlide(i)}
                className={`w-full rounded-xl px-3 py-2.5 text-left text-xs transition ${
                  activeSlide === i
                    ? "bg-gradient-to-r from-indigo-500 to-violet-500 text-white shadow-md"
                    : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                <span className="font-extrabold">{s.number}.</span> {s.title}
              </button>
            ))}
          </div>
        </div>

        {/* Active slide */}
        <div className="flex-1 p-5" style={{ minHeight: 340 }}>
          {result.slides[activeSlide] && (() => {
            const slide = result.slides[activeSlide];
            return (
              <div className="flex h-full flex-col">
                <div className="flex items-center justify-between mb-5">
                  <span className={`inline-flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br ${slideColor(slide.title)} text-sm font-extrabold text-white`}>
                    {slide.number}
                  </span>
                  <div className="flex gap-1">
                    <button
                      onClick={() => setActiveSlide(Math.max(0, activeSlide - 1))}
                      disabled={activeSlide === 0}
                      className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-600 disabled:opacity-40 hover:bg-slate-50"
                    >‹ Prev</button>
                    <button
                      onClick={() => setActiveSlide(Math.min(result.slides.length - 1, activeSlide + 1))}
                      disabled={activeSlide === result.slides.length - 1}
                      className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-600 disabled:opacity-40 hover:bg-slate-50"
                    >Next ›</button>
                  </div>
                </div>

                {/* Slide title */}
                <h3 className={`mb-4 text-2xl font-extrabold bg-gradient-to-r ${slideColor(slide.title)} bg-clip-text text-transparent`}>
                  {slide.title}
                </h3>

                {/* Bullets */}
                <ul className="flex-1 space-y-3">
                  {slide.content.map((b, i) => (
                    <li key={i} className="flex items-start gap-3 rounded-xl bg-slate-50 px-4 py-3">
                      <span className={`mt-1 shrink-0 h-2 w-2 rounded-full bg-gradient-to-r ${slideColor(slide.title)}`} />
                      <span className="text-sm font-medium text-slate-700 leading-6">{b}</span>
                    </li>
                  ))}
                </ul>

                {/* Notes & visual */}
                <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div className="rounded-xl border border-amber-100 bg-amber-50 p-3">
                    <p className="mb-1 text-[10px] font-extrabold uppercase tracking-wide text-amber-600">🎤 Speaker Notes</p>
                    <p className="text-xs leading-5 text-amber-800">{slide.speaker_notes}</p>
                  </div>
                  <div className="rounded-xl border border-indigo-100 bg-indigo-50 p-3">
                    <p className="mb-1 text-[10px] font-extrabold uppercase tracking-wide text-indigo-600">🎨 Visual Suggestion</p>
                    <p className="text-xs leading-5 text-indigo-800">{slide.visual_suggestion}</p>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      </div>

      {/* Progress dots */}
      <div className="border-t border-slate-100 px-6 py-3">
        <div className="flex items-center justify-center gap-2">
          {result.slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setActiveSlide(i)}
              className={`h-2 rounded-full transition-all ${i === activeSlide ? "w-8 bg-indigo-500" : "w-2 bg-slate-200 hover:bg-indigo-300"}`}
            />
          ))}
        </div>
      </div>
    </article>
  );
}
