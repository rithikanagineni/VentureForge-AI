"use client";

import { AGENTS } from "@/lib/agents";
import {
  buildActivityChart,
  buildAgentBreakdown,
  buildRecommendations,
} from "@/lib/recommendations";
import type { HistoryItem } from "@/lib/types";
import type { ViewId } from "../Sidebar";

export default function Dashboard({
  history,
  onNavigate,
  onOpenHistory,
  onQuickAction,
}: {
  history: HistoryItem[];
  onNavigate: (v: ViewId) => void;
  onOpenHistory: (item: HistoryItem) => void;
  onQuickAction: (agentId: string) => void;
}) {
  const total = history.length;
  const agentsUsed = new Set(history.map((h) => h.agentId)).size;
  const lastActive = history[0]
    ? new Date(history[0].createdAt).toLocaleDateString()
    : "—";

  const stats = [
    { label: "Reports Generated", value: total, icon: "📄", color: "from-indigo-500 to-violet-500" },
    { label: "Agents Used", value: agentsUsed, icon: "🤖", color: "from-fuchsia-500 to-pink-500" },
    { label: "Available Agents", value: AGENTS.length, icon: "⚡", color: "from-amber-400 to-orange-500" },
    { label: "Last Active", value: lastActive, icon: "🕐", color: "from-teal-400 to-emerald-500" },
  ];

  const investorReadiness = [
    { id: "business_plan", label: "Business Plan", icon: "📋" },
    { id: "market_research", label: "Market Research", icon: "📊" },
    { id: "competitor_analysis", label: "Competitor Analysis", icon: "⚔️" },
    { id: "revenue_model", label: "Revenue Model", icon: "📈" },
    { id: "funding", label: "Funding Strategy", icon: "💰" },
    { id: "investor_pitch", label: "Investor Pitch", icon: "🎤" },
  ].map((item) => ({
    ...item,
    complete: history.some((h) => h.agentId === item.id),
  }));

  const readinessScore = Math.round(
    (investorReadiness.filter((item) => item.complete).length / investorReadiness.length) * 100,
  );

  const scoreColor =
    readinessScore >= 80
      ? "from-emerald-500 to-teal-500"
      : readinessScore >= 40
      ? "from-amber-400 to-orange-500"
      : "from-indigo-500 to-fuchsia-500";

  const recommendations = buildRecommendations(history);
  const activityChart = buildActivityChart(history);
  const maxActivity = Math.max(...activityChart.map((d) => d.count), 1);
  const agentBreakdown = buildAgentBreakdown(history);

  // Business Health Dashboard — donut chart segments
  const segments = investorReadiness.map((item) => ({
    label: item.label, complete: item.complete,
  }));
  const done = segments.filter((s) => s.complete).length;
  const donutR = 44;
  const donutC = 2 * Math.PI * donutR;
  const donePct = segments.length > 0 ? done / segments.length : 0;

  return (
    <div className="mx-auto max-w-5xl space-y-8 vf-fade-up">

      {/* Header */}
      <header className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-[.18em] text-indigo-600">Overview</p>
          <h1 className="mt-2 text-3xl font-extrabold text-slate-900">Dashboard</h1>
          <p className="mt-1 text-slate-500">
            Welcome back, founder. Here&apos;s your venture activity.
          </p>
        </div>
        <button
          onClick={() => onNavigate("copilot")}
          className="vf-btn-gradient rounded-2xl px-6 py-3 text-sm font-bold text-white"
        >
          🚀 Launch Copilot
        </button>
      </header>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="vf-card p-5">
            <div className={`inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${s.color} text-lg`}>
              {s.icon}
            </div>
            <div className="mt-3 text-2xl font-extrabold text-slate-900">{s.value}</div>
            <div className="mt-0.5 text-xs font-medium text-slate-500">{s.label}</div>
          </div>
        ))}
      </div>

      {/* AI Recommendations + Weekly Activity */}
      <div className="grid gap-5 lg:grid-cols-2">
        {/* AI Recommendations */}
        <section className="vf-card p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-base font-extrabold text-slate-900">🎯 AI Recommendations</h2>
            <span className="rounded-full bg-indigo-50 px-2 py-0.5 text-[10px] font-bold text-indigo-600">Personalised</span>
          </div>
          <div className="space-y-2">
            {recommendations.map((r, i) => (
              <div
                key={i}
                className={`flex items-start gap-3 rounded-2xl border px-4 py-3 text-sm ${
                  r.category === "action" ? "border-indigo-100 bg-indigo-50/60" :
                  r.category === "warning" ? "border-rose-100 bg-rose-50/60" :
                  r.category === "milestone" ? "border-amber-100 bg-amber-50/60" :
                  "border-slate-100 bg-slate-50"
                }`}
              >
                <span className="mt-0.5 text-base">{r.icon}</span>
                <p className={`leading-5 ${
                  r.category === "milestone" ? "font-bold text-amber-800" :
                  r.category === "action" ? "font-semibold text-indigo-800" :
                  r.category === "warning" ? "font-semibold text-rose-800" :
                  "text-slate-600"
                }`}>{r.text}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Usage stats */}
        <section className="vf-card p-6">
          <h2 className="mb-4 text-base font-extrabold text-slate-900">📊 Usage — Last 7 Days</h2>
          {/* Simple SVG bar chart */}
          <div className="flex items-end gap-2" style={{ height: 100 }}>
            {activityChart.map(({ day, count }) => {
              const h = count === 0 ? 6 : Math.max(14, Math.min(100, (count / maxActivity) * 100));
              return (
                <div key={day} className="flex flex-1 flex-col items-center gap-1">
                  <span className="text-[10px] font-bold text-slate-500">{count > 0 ? count : ""}</span>
                  <div
                    className="w-full rounded-t-md transition-all duration-500"
                    style={{
                      height: `${h}%`,
                      background: count > 0
                        ? "linear-gradient(180deg,#6366f1,#a855f7)"
                        : "#e8edf5",
                    }}
                  />
                  <span className="text-[10px] font-bold text-slate-400">{day}</span>
                </div>
              );
            })}
          </div>

          {/* Agent breakdown */}
          {agentBreakdown.length > 0 && (
            <div className="mt-5 space-y-2">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wide">Top Agents Used</p>
              {agentBreakdown.slice(0, 4).map(({ name, count, pct }) => (
                <div key={name}>
                  <div className="mb-0.5 flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700">{name}</span>
                    <span className="text-xs font-bold text-slate-500">{count}</span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-fuchsia-500 transition-all duration-700"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Business Health Dashboard */}
      <section className="vf-card p-7">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-lg font-extrabold text-slate-900">📊 Business Health Dashboard</h2>
          <span className="rounded-full bg-indigo-50 px-3 py-1 text-xs font-bold text-indigo-600">live metrics</span>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
          {/* Donut chart */}
          <div className="flex flex-col items-center">
            <svg width="130" height="130" viewBox="0 0 130 130" className="rounded-full shadow-md shadow-indigo-100">
              <circle cx="65" cy="65" r={donutR} fill="none" stroke="#e8edf5" strokeWidth="18" />
              {/* Done portion */}
              <circle
                cx="65" cy="65" r={donutR} fill="none"
                stroke="url(#donutGrad)" strokeWidth="18"
                strokeLinecap="round"
                strokeDasharray={`${donePct * donutC} ${donutC}`}
                transform="rotate(-90 65 65)"
                className="transition-all duration-1000"
              />
              <defs>
                <linearGradient id="donutGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#6366f1" />
                  <stop offset="100%" stopColor="#a855f7" />
                </linearGradient>
              </defs>
              {/* Center label */}
              <text x="65" y="60" textAnchor="middle" className="fill-current font-extrabold" style={{ fontSize: 24, fill: "#4f46e5" }}>
                {done}/6
              </text>
              <text x="65" y="76" textAnchor="middle" style={{ fontSize: 10, fill: "#94a3b8" }}>reports done</text>
            </svg>
            <p className="mt-3 text-center text-xs font-bold text-slate-500">Core reports completed</p>
          </div>

          {/* Business metrics */}
          <div className="col-span-2 grid grid-cols-2 gap-3">
            {[
              { label: "Reports Generated", value: history.length, icon: "📄", grad: "from-indigo-500 to-violet-500" },
              { label: "Agent Types Used", value: new Set(history.map((h) => h.agentId)).size, icon: "🤖", grad: "from-fuchsia-500 to-pink-500" },
              { label: "Sessions", value: new Set(history.map((h) => h.sessionId)).size, icon: "💬", grad: "from-cyan-500 to-teal-500" },
              { label: "This Week", value: activityChart.reduce((a, b) => a + b.count, 0), icon: "📅", grad: "from-amber-400 to-orange-500" },
            ].map(({ label, value, icon, grad }) => (
              <div key={label} className="rounded-2xl border border-slate-100 bg-slate-50 p-4">
                <div className={`inline-flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br ${grad} text-sm`}>
                  {icon}
                </div>
                <div className="mt-2 text-2xl font-extrabold text-slate-900">{value}</div>
                <div className="text-xs text-slate-500">{label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Investor readiness detail */}
        <div className="mt-6">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-xs font-extrabold text-slate-500 uppercase tracking-wide">Investor Readiness Progress</p>
            <span className="text-xs font-bold text-slate-600">{done}/6 items</span>
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {investorReadiness.map((item) => (
              <button
                key={item.id}
                onClick={() => onQuickAction(item.id)}
                className={`flex items-center gap-2 rounded-2xl border px-3 py-2 text-xs font-bold text-left transition hover:shadow-sm ${
                  item.complete
                    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                    : "border-slate-100 bg-white text-slate-500 hover:border-indigo-100"
                }`}
              >
                <span>{item.icon}</span> {item.complete ? "✓" : "○"} {item.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Investor Readiness Score */}
      <section className="vf-card overflow-hidden p-7">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-[.18em] text-fuchsia-600">Founder milestone</p>
            <h2 className="mt-2 text-xl font-extrabold text-slate-900">Investor Readiness Score</h2>
            <p className="mt-1 text-sm text-slate-500">
              Complete the 6 core reports that every investor expects before a pitch.
            </p>
          </div>
          <div className="text-right">
            <div className={`text-5xl font-extrabold vf-gradient-text`}>{readinessScore}%</div>
            <div className="text-xs font-bold text-slate-500">ready</div>
          </div>
        </div>
        <div className="mt-5 h-3 overflow-hidden rounded-full bg-slate-100">
          <div
            className={`h-full rounded-full bg-gradient-to-r ${scoreColor} transition-all duration-700`}
            style={{ width: `${readinessScore}%` }}
          />
        </div>
        <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-3">
          {investorReadiness.map((item) => (
            <button
              key={item.id}
              onClick={() => onQuickAction(item.id)}
              className={`flex items-center gap-2 rounded-2xl border px-3 py-2.5 text-sm font-semibold transition hover:shadow-sm ${
                item.complete
                  ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                  : "border-slate-200 bg-white text-slate-500 hover:border-indigo-200 hover:text-indigo-700"
              }`}
            >
              <span>{item.icon}</span>
              <span>{item.complete ? "✓" : "○"} {item.label}</span>
            </button>
          ))}
        </div>
        {readinessScore === 100 && (
          <div className="mt-4 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-bold text-emerald-700">
            🎉 You are investor-ready! All core reports completed.
          </div>
        )}
      </section>

      {/* All agents — clickable from dashboard */}
      <section>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-extrabold text-slate-900">Your AI Agent Suite</h2>
          <span className="rounded-full bg-indigo-50 px-3 py-1 text-xs font-bold text-indigo-600">
            {AGENTS.length} agents
          </span>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {AGENTS.map((a) => (
            <button
              key={a.id}
              onClick={() => onQuickAction(a.id)}
              className="vf-card group p-4 text-left transition hover:-translate-y-0.5 hover:shadow-lg hover:ring-1 hover:ring-indigo-200"
            >
              <div className="flex items-center gap-3">
                <span className={`inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${a.gradient} shadow-sm`}>
                  {a.icon}
                </span>
                <div className="min-w-0">
                  <div className="truncate text-sm font-extrabold text-slate-800">
                    {a.name.replace(" Agent", "")}
                  </div>
                  <div className="text-[11px] text-slate-500">{a.tagline}</div>
                </div>
              </div>
              <p className="mt-2.5 text-xs leading-5 text-slate-500">{a.description}</p>
            </button>
          ))}
        </div>
      </section>

      {/* Recent reports */}
      <section>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-extrabold text-slate-900">Recent Reports</h2>
          {history.length > 0 && (
            <span className="text-xs text-slate-400">{history.length} total</span>
          )}
        </div>
        {history.length === 0 ? (
          <div className="vf-card p-10 text-center">
            <div className="text-4xl">🚀</div>
            <div className="mt-3 text-sm font-bold text-slate-600">No reports yet</div>
            <p className="mt-1 text-xs text-slate-400">
              Launch the Copilot to generate your first IBM Granite blueprint.
            </p>
            <button
              onClick={() => onNavigate("copilot")}
              className="vf-btn-gradient mx-auto mt-4 block rounded-xl px-5 py-2.5 text-sm font-bold text-white"
            >
              Get Started
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {history.slice(0, 8).map((h) => (
              <button
                key={h.id}
                onClick={() => onOpenHistory(h)}
                className="vf-card flex w-full items-center gap-3 px-5 py-4 text-left transition hover:-translate-y-px hover:shadow-md hover:ring-1 hover:ring-indigo-100"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-100 to-fuchsia-100 text-sm">
                  🧾
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-bold text-slate-800">{h.title}</div>
                  <div className="mt-0.5 text-xs text-slate-500">
                    {h.agentName} · {new Date(h.createdAt).toLocaleString()}
                  </div>
                </div>
                <span className="shrink-0 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700">
                  Granite
                </span>
              </button>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
