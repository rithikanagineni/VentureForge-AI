"use client";

import { useEffect, useState } from "react";
import type { HistoryItem } from "@/lib/types";

type Accent = "violet" | "blue" | "rose";
type Theme = "light" | "dark";

export default function Settings({
  history,
  onClearHistory,
  clearing,
}: {
  history: HistoryItem[];
  onClearHistory: () => void;
  clearing: boolean;
}) {
  const [accent, setAccent] = useState<Accent>("violet");
  const [theme, setTheme] = useState<Theme>("light");
  const [compact, setCompact] = useState(false);
  const [reduceMotion, setReduceMotion] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const at = localStorage.getItem("vf-accent") as Accent | null;
    const th = (localStorage.getItem("vf-theme") as Theme | null) || "light";
    const co = localStorage.getItem("vf-compact") === "true";
    const rm = localStorage.getItem("vf-reduce-motion") === "true";
    if (at) setAccent(at);
    setTheme(th); setCompact(co); setReduceMotion(rm);
    document.documentElement.dataset.accent = at || "violet";
    document.documentElement.dataset.theme = th;
    document.documentElement.dataset.compact = String(co);
    document.documentElement.dataset.reduceMotion = String(rm);
  }, []);

  const applyAccent = (value: Accent) => {
    setAccent(value);
    localStorage.setItem("vf-accent", value);
    document.documentElement.dataset.accent = value;
    flashSaved();
  };

  const applyTheme = () => {
    const next: Theme = theme === "light" ? "dark" : "light";
    setTheme(next);
    localStorage.setItem("vf-theme", next);
    document.documentElement.dataset.theme = next;
    flashSaved();
  };

  const applyCompact = () => {
    const v = !compact;
    setCompact(v);
    localStorage.setItem("vf-compact", String(v));
    document.documentElement.dataset.compact = String(v);
    flashSaved();
  };

  const applyMotion = () => {
    const v = !reduceMotion;
    setReduceMotion(v);
    localStorage.setItem("vf-reduce-motion", String(v));
    document.documentElement.dataset.reduceMotion = String(v);
    flashSaved();
  };

  const flashSaved = () => { setSaved(true); setTimeout(() => setSaved(false), 1400); };

  const exportHistory = () => {
    const blob = new Blob([JSON.stringify(history, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ventureforge-history-${new Date().toISOString().slice(0, 10)}.json`;
    a.click(); URL.revokeObjectURL(url);
  };

  const sectionCls = "vf-card p-6";
  const titleCls = "text-lg font-extrabold text-slate-900";
  const subCls = "mt-0.5 text-sm text-slate-500";

  return (
    <div className="mx-auto max-w-3xl space-y-6 vf-fade-up">
      <header className="flex items-center justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-[.18em] text-indigo-600">Workspace</p>
          <h1 className="mt-2 text-3xl font-extrabold text-slate-900">Settings</h1>
          <p className={subCls}>Personalize your VentureForge experience.</p>
        </div>
        {saved && (
          <span className="rounded-full bg-emerald-100 px-3 py-1.5 text-xs font-bold text-emerald-700">✓ Saved</span>
        )}
      </header>

      {/* Theme */}
      <section className={sectionCls}>
        <h2 className={titleCls}>🌓 Appearance</h2>
        <p className={subCls}>Choose how the app looks for you.</p>

        {/* Dark / Light mode */}
        <div className="mt-5 flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 px-5 py-4">
          <div>
            <div className="text-sm font-extrabold text-slate-800">🌙 Dark Mode</div>
            <div className="text-xs text-slate-500">Switch to a dark background</div>
          </div>
          <button
            role="switch"
            aria-checked={theme === "dark"}
            onClick={applyTheme}
            className={`relative h-8 w-14 rounded-full transition-all ${theme === "dark" ? "shadow-md shadow-indigo-300" : "bg-slate-300"} `}
            style={theme === "dark" ? { background: "linear-gradient(90deg,#4f46e5,#a855f7)" } : {}}
          >
            <span
              className="absolute top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-white text-[10px] shadow transition-all"
              style={{ left: theme === "dark" ? "30px" : "4px" }}
            >
              {theme === "dark" ? "🌙" : "☀️"}
            </span>
          </button>
        </div>

        {/* Accent color */}
        <div className="mt-4">
          <p className="mb-3 text-sm font-bold text-slate-700">Accent color</p>
          <div className="grid grid-cols-3 gap-3">
            {([
              ["violet", "Violet", "from-indigo-500 to-violet-500"],
              ["blue", "Ocean", "from-sky-500 to-blue-600"],
              ["rose", "Sunset", "from-orange-400 to-rose-500"],
            ] as const).map(([value, label, gradient]) => (
              <button
                key={value}
                onClick={() => applyAccent(value)}
                className={`rounded-2xl border p-3 text-left transition ${accent === value ? "border-indigo-500 bg-indigo-50 ring-2 ring-indigo-100" : "border-slate-200 bg-white hover:border-indigo-300"}`}
              >
                <span className={`mb-2 block h-8 rounded-xl bg-gradient-to-r ${gradient}`} />
                <span className="text-xs font-bold text-slate-700">{label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Toggles */}
        <div className="mt-4 divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white px-4">
          <ToggleRow label="Compact layout" desc="Reduce spacing across the interface" active={compact} onClick={applyCompact} />
          <ToggleRow label="Reduce motion" desc="Disable animations for accessibility" active={reduceMotion} onClick={applyMotion} />
        </div>
      </section>

      {/* Data */}
      <section className={sectionCls}>
        <h2 className={titleCls}>📦 Your Data</h2>
        <p className={subCls}>Export or permanently remove your generated report history.</p>
        <div className="mt-5 flex flex-wrap gap-3">
          <button
            onClick={exportHistory}
            disabled={history.length === 0}
            className="rounded-xl border border-indigo-200 bg-indigo-50 px-4 py-2.5 text-sm font-bold text-indigo-700 transition hover:bg-indigo-100 disabled:cursor-not-allowed disabled:opacity-40"
          >
            ↓ Export History as JSON ({history.length})
          </button>
          <button
            onClick={onClearHistory}
            disabled={clearing || history.length === 0}
            className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-2.5 text-sm font-bold text-rose-700 transition hover:bg-rose-100 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {clearing ? "Clearing…" : "🗑 Delete All History"}
          </button>
        </div>
      </section>
    </div>
  );
}

function ToggleRow({ label, desc, active, onClick }: { label: string; desc: string; active: boolean; onClick: () => void }) {
  return (
    <div className="flex items-center justify-between gap-4 py-4">
      <div>
        <div className="text-sm font-extrabold text-slate-800">{label}</div>
        <div className="text-xs text-slate-500">{desc}</div>
      </div>
      <button
        role="switch"
        aria-checked={active}
        onClick={onClick}
        className={`relative h-7 w-12 rounded-full transition ${active ? "bg-indigo-600" : "bg-slate-300"}`}
      >
        <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition ${active ? "left-6" : "left-1"}`} />
      </button>
    </div>
  );
}
