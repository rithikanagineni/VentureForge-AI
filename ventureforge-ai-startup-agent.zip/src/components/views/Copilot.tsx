"use client";

import StartupForm from "../StartupForm";
import QuickActions from "../QuickActions";
import ResultCard, { type ResultData } from "../ResultCard";
import HealthScoreCard from "@/components/HealthScoreCard";
import InvestorDecisionCard from "@/components/InvestorDecisionCard";
import PitchDeckCard from "@/components/PitchDeckCard";
import InteractiveRoadmapCard from "@/components/InteractiveRoadmapCard";
import type {
  HealthScoreResult,
  InvestorDecisionResult,
  PitchDeckResult,
  StartupForm as FormType,
} from "@/lib/types";

export default function Copilot({
  form,
  setForm,
  prompt,
  setPrompt,
  loading,
  error,
  success,
  results,
  typedOutput,
  typingActive,
  healthData,
  investorData,
  pitchData,
  onGenerate,
  onQuickAction,
  onInvestorPack,
  onNewChat,
  onClearHistory,
  clearing,
}: {
  form: FormType;
  setForm: (f: FormType) => void;
  prompt: string;
  setPrompt: (p: string) => void;
  loading: boolean;
  error: string | null;
  success: string | null;
  results: ResultData[];
  typedOutput: string;
  typingActive: boolean;
  healthData: HealthScoreResult | null;
  investorData: InvestorDecisionResult | null;
  pitchData: PitchDeckResult | null;
  onGenerate: () => void;
  onQuickAction: (agentId: string) => void;
  onInvestorPack: () => void;
  onNewChat: () => void;
  onClearHistory: () => void;
  clearing: boolean;
}) {
  return (
    <div className="mx-auto max-w-4xl space-y-6">
      {/* Hero */}
      <section className="vf-card vf-glow relative overflow-hidden p-8 vf-fade-up">
        <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-violet-300/30 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-20 -left-10 h-64 w-64 rounded-full bg-pink-300/25 blur-3xl" />
        <div className="relative">
          <span className="inline-flex items-center gap-2 rounded-full border border-indigo-200 bg-indigo-50 px-3 py-1 text-[11px] font-bold text-indigo-700">
            ✦ Powered by IBM Granite · IBM Cloud
          </span>
          <h1 className="mt-4 text-4xl font-extrabold leading-tight text-slate-900 sm:text-5xl">
            Turn your idea into a{" "}
            <span className="vf-gradient-text">startup blueprint</span>
          </h1>
          <p className="mt-3 max-w-2xl leading-7 text-slate-600">
            Describe your startup and let your AI Copilot generate business plans, pitch decks,
            market research, funding strategies and more — in seconds.
          </p>
        </div>
      </section>

      {/* Startup profile form */}
      <section className="vf-card p-6 vf-fade-up">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-[.18em] text-indigo-600">Step 1</p>
            <h2 className="mt-1 text-base font-extrabold text-slate-900">Startup Profile</h2>
          </div>
          <div className="flex gap-2">
            <button onClick={onNewChat} className="vf-secondary-button">✦ New Session</button>
            <button onClick={onClearHistory} disabled={clearing} className="vf-secondary-button disabled:opacity-50">🗑 Clear History</button>
          </div>
        </div>

        <StartupForm form={form} onChange={setForm} />

        {/* Prompt */}
        <div className="mt-5">
          <p className="mb-1 text-xs font-bold uppercase tracking-[.18em] text-indigo-600">Step 2</p>
          <label className="mb-2 block text-base font-extrabold text-slate-900">
            Ask your Copilot anything
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="e.g. Validate my SaaS idea for HR teams, create a full business plan, generate an investor pitch deck, do a SWOT analysis, build a 12-month roadmap…"
            className="min-h-[120px] w-full resize-y rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-800 placeholder-slate-400 outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
            onKeyDown={(e) => {
              if ((e.ctrlKey || e.metaKey) && e.key === "Enter") onGenerate();
            }}
          />
          <p className="mt-1 text-right text-[11px] text-slate-400">⌨ Ctrl+Enter to generate</p>
        </div>

        {/* Actions */}
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <button
            onClick={onGenerate}
            disabled={loading}
            className="vf-btn-gradient flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-bold text-white"
          >
            {loading ? <><LoadingDots /> Generating…</> : <>✨ Generate Blueprint</>}
          </button>
          <button
            onClick={onInvestorPack}
            disabled={loading}
            className="rounded-xl border border-violet-200 bg-gradient-to-r from-violet-50 to-fuchsia-50 px-5 py-3 text-sm font-bold text-violet-700 shadow-sm transition hover:from-violet-100 hover:to-fuchsia-100 disabled:cursor-not-allowed disabled:opacity-50"
          >
            💼 Investor Pack
          </button>
          <button
            onClick={() => onQuickAction("startup_health")}
            disabled={loading}
            className="rounded-xl border border-rose-200 bg-gradient-to-r from-rose-50 to-pink-50 px-5 py-3 text-sm font-bold text-rose-700 shadow-sm transition hover:from-rose-100 hover:to-pink-100 disabled:cursor-not-allowed disabled:opacity-50"
          >
            🏥 Health Score
          </button>
          <span className="text-xs text-slate-400">
            Ctrl+Enter · More specialised actions below
          </span>
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-medium text-rose-700">
            ⚠️ {error}
          </div>
        )}
        {success && !error && (
          <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-700">
            ✅ {success}
          </div>
        )}
      </section>

      {/* Specialised agent actions */}
      <section className="vf-card p-6 vf-fade-up">
        <div className="mb-4">
          <p className="text-xs font-bold uppercase tracking-[.18em] text-rose-600">Pro Features</p>
          <h2 className="mt-1 text-base font-extrabold text-slate-900">Advanced AI Actions</h2>
          <p className="mt-1 text-xs text-slate-500">Structured interactive outputs powered by IBM Granite.</p>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {[
            { id: "startup_health", label: "🏥 Health Score", sub: "8-dim gauge", color: "border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700" },
            { id: "investor_decision", label: "💼 Investor Simulator", sub: "3 verdicts", color: "border-amber-200 bg-amber-50 hover:bg-amber-100 text-amber-700" },
            { id: "pitch_deck", label: "📈 Pitch Deck", sub: "Slide-by-slide", color: "border-sky-200 bg-sky-50 hover:bg-sky-100 text-sky-700" },
            { id: "roadmap", label: "🗺️ Roadmap", sub: "Interactive", color: "border-violet-200 bg-violet-50 hover:bg-violet-100 text-violet-700" },
            { id: "customer_persona", label: "🧑 Personas", sub: "Buyer profiles", color: "border-teal-200 bg-teal-50 hover:bg-teal-100 text-teal-700" },
            { id: "competitor_analysis", label: "⚔️ Competitors", sub: "Comparison", color: "border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700" },
            { id: "swot", label: "🧭 SWOT", sub: "Strategy", color: "border-orange-200 bg-orange-50 hover:bg-orange-100 text-orange-700" },
            { id: "financial_projections", label: "💹 Financials", sub: "3-yr model", color: "border-lime-200 bg-lime-50 hover:bg-lime-100 text-lime-700" },
          ].map(({ id, label, sub, color }) => (
            <button
              key={id}
              onClick={() => onQuickAction(id)}
              disabled={loading}
              className={`rounded-2xl border px-3 py-3 text-left transition hover:shadow-sm disabled:cursor-not-allowed disabled:opacity-40 ${color}`}
            >
              <div className="text-xs font-extrabold">{label}</div>
              <div className="mt-0.5 text-[10px] opacity-70">{sub}</div>
            </button>
          ))}
        </div>
      </section>

      {/* Quick actions */}
      <section className="vf-card p-6 vf-fade-up">
        <div className="mb-4">
          <p className="text-xs font-bold uppercase tracking-[.18em] text-indigo-600">Step 3 — optional</p>
          <h2 className="mt-1 text-base font-extrabold text-slate-900">All 15 Agents</h2>
          <p className="mt-1 text-xs text-slate-500">Select any specialized AI agent directly.</p>
        </div>
        <QuickActions onSelect={onQuickAction} disabled={loading} />
      </section>

      {/* Structured Agent Outputs */}
      <div className="space-y-5">
        {healthData && (
          <HealthScoreCard result={healthData} />
        )}
        {investorData && (
          <InvestorDecisionCard result={investorData} />
        )}
        {pitchData && (
          <PitchDeckCard result={pitchData} />
        )}
        {/* Interactive roadmap — rendered when a roadmap result exists and was the most recent */}
        {results.find((r) => r.agentId === "roadmap") && (
          <InteractiveRoadmapCard markdown={results.find((r) => r.agentId === "roadmap")!.output} />
        )}
      </div>

      {/* Loading skeleton */}
      {loading && <ResultSkeleton />}

      {/* Results with typing effect on the latest */}
      {results.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-extrabold text-slate-900">📑 Generated Reports</h2>
            <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600">
              {results.length} report{results.length !== 1 ? "s" : ""}
            </span>
          </div>
          {results.map((r, i) => (
            <ResultCard
              key={r.id}
              data={r}
              defaultOpen={i === 0}
              liveOutput={i === 0 && typingActive ? typedOutput : undefined}
            />
          ))}
        </section>
      )}
    </div>
  );
}

function LoadingDots() {
  return (
    <span className="inline-flex items-center gap-1">
      <span className="vf-dot h-1.5 w-1.5 rounded-full bg-white" style={{ animationDelay: "0s" }} />
      <span className="vf-dot h-1.5 w-1.5 rounded-full bg-white" style={{ animationDelay: "0.2s" }} />
      <span className="vf-dot h-1.5 w-1.5 rounded-full bg-white" style={{ animationDelay: "0.4s" }} />
    </span>
  );
}

function ResultSkeleton() {
  return (
    <div className="vf-card space-y-4 p-7">
      <div className="flex items-center gap-3">
        <div className="vf-shimmer h-10 w-10 rounded-xl" />
        <div className="flex-1 space-y-2">
          <div className="vf-shimmer h-4 w-1/3 rounded" />
          <div className="vf-shimmer h-3 w-1/2 rounded" />
        </div>
      </div>
      <div className="space-y-2.5">
        <div className="vf-shimmer h-3 w-full rounded" />
        <div className="vf-shimmer h-3 w-11/12 rounded" />
        <div className="vf-shimmer h-3 w-4/5 rounded" />
        <div className="vf-shimmer h-24 w-full rounded-xl" />
        <div className="vf-shimmer h-3 w-3/4 rounded" />
        <div className="vf-shimmer h-3 w-5/6 rounded" />
      </div>
    </div>
  );
}
