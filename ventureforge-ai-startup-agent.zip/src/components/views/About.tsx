"use client";

import { AGENTS } from "@/lib/agents";

export default function About() {
  return (
    <div className="mx-auto max-w-5xl space-y-8 vf-fade-up">
      <header className="rounded-[2rem] border border-white/80 bg-white/65 p-8 shadow-xl shadow-indigo-100/60 backdrop-blur-xl">
        <p className="text-xs font-bold uppercase tracking-[.2em] text-indigo-600">Our purpose</p>
        <h1 className="mt-3 text-4xl font-extrabold text-slate-900">
          Build with clarity. <span className="vf-gradient-text">Move with confidence.</span>
        </h1>
        <p className="mt-4 max-w-3xl text-base leading-7 text-slate-600">
          VentureForge AI is an intelligent startup copilot that transforms raw ideas into complete,
          actionable business blueprints—helping founders move from first thought to investor readiness.
        </p>
      </header>

      <section className="grid gap-5 md:grid-cols-2">
        <div className="vf-card p-6">
          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-100 text-xl">◎</span>
          <h2 className="mt-4 text-lg font-bold text-slate-900">Our mission</h2>
          <p className="mt-2 text-sm leading-6 text-slate-600">
            Eliminate uncertainty for aspiring entrepreneurs with practical direction across validation,
            markets, funding, competition, revenue, marketing, and execution.
          </p>
        </div>
        <div className="vf-card p-6">
          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-fuchsia-100 text-xl">✦</span>
          <h2 className="mt-4 text-lg font-bold text-slate-900">Intelligence that acts</h2>
          <p className="mt-2 text-sm leading-6 text-slate-600">
            Specialized agents combine your startup context with IBM Granite to produce structured,
            specific, and exportable reports—not generic templates.
          </p>
        </div>
      </section>

      <section>
        <div className="mb-5">
          <p className="text-xs font-bold uppercase tracking-[.18em] text-fuchsia-600">Specialists</p>
          <h2 className="mt-2 text-2xl font-extrabold text-slate-900">A complete AI agent team</h2>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {AGENTS.map((agent) => (
            <div key={agent.id} className="vf-card group p-5 transition hover:-translate-y-1 hover:shadow-xl">
              <div className={`inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${agent.gradient} text-base shadow-sm`}>
                {agent.icon}
              </div>
              <div className="mt-3 text-sm font-bold text-slate-900">{agent.name}</div>
              <p className="mt-1 text-xs leading-5 text-slate-500">{agent.description}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
