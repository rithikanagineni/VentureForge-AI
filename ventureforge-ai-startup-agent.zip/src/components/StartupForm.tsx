"use client";

import type { StartupForm as FormType } from "@/lib/types";

const STAGES = [
  "Idea",
  "Pre-Seed",
  "MVP / Prototype",
  "Early Revenue",
  "Growth",
  "Scaling",
];

const FIELD =
  "w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-800 placeholder-slate-400 outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100";

export default function StartupForm({
  form,
  onChange,
}: {
  form: FormType;
  onChange: (form: FormType) => void;
}) {
  const set = (key: keyof FormType, value: string) =>
    onChange({ ...form, [key]: value });

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <Field label="Startup Name">
        <input
          className={FIELD}
          placeholder="e.g. NovaPay"
          value={form.startupName}
          onChange={(e) => set("startupName", e.target.value)}
        />
      </Field>

      <Field label="Industry">
        <input
          className={FIELD}
          placeholder="e.g. Fintech, HealthTech"
          value={form.industry}
          onChange={(e) => set("industry", e.target.value)}
        />
      </Field>

      <Field label="Country / Market">
        <input
          className={FIELD}
          placeholder="e.g. India, USA, Global"
          value={form.country}
          onChange={(e) => set("country", e.target.value)}
        />
      </Field>

      <Field label="Budget">
        <input
          className={FIELD}
          placeholder="e.g. $10,000 bootstrap"
          value={form.budget}
          onChange={(e) => set("budget", e.target.value)}
        />
      </Field>

      <Field label="Business Stage">
        <select
          className={FIELD}
          value={form.stage}
          onChange={(e) => set("stage", e.target.value)}
        >
          <option value="">Select stage…</option>
          {STAGES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </Field>

      <Field label="Target Customers">
        <input
          className={FIELD}
          placeholder="e.g. SMB owners, students"
          value={form.targetCustomers}
          onChange={(e) => set("targetCustomers", e.target.value)}
        />
      </Field>

      <div className="sm:col-span-2">
        <Field label="Problem Statement">
          <textarea
            className={`${FIELD} min-h-[70px] resize-y`}
            placeholder="What painful problem are you solving?"
            value={form.problem}
            onChange={(e) => set("problem", e.target.value)}
          />
        </Field>
      </div>

      <div className="sm:col-span-2">
        <Field label="Startup Description">
          <textarea
            className={`${FIELD} min-h-[70px] resize-y`}
            placeholder="Describe your idea in a few sentences…"
            value={form.description}
            onChange={(e) => set("description", e.target.value)}
          />
        </Field>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-slate-400">
        {label}
      </span>
      {children}
    </label>
  );
}
