"use client";

import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import Sidebar, { type ViewId } from "./Sidebar";
import Dashboard from "./views/Dashboard";
import Copilot from "./views/Copilot";
import About from "./views/About";
import Settings from "./views/Settings";
import type { ResultData } from "./ResultCard";
import {
  HEALTH_SCORE_AGENT,
  INVESTOR_DECISION_AGENT,
  PITCH_DECK_AGENT,
  AGENT_MAP,
  GENERAL_AGENT,
} from "@/lib/agents";
import {
  EMPTY_FORM,
  type GenerateResponse,
  type HealthScoreResult,
  type HistoryItem,
  type InvestorDecisionResult,
  type PitchDeckResult,
  type SavedProject,
  type StartupForm,
} from "@/lib/types";

function newSessionId() {
  return `s_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

const INVESTOR_PACK_AGENTS = [
  "business_plan",
  "market_research",
  "competitor_analysis",
  "revenue_model",
  "funding",
  "investor_pitch",
];

/** Simulate streaming by revealing text token-by-token after generation. */
function useTypingEffect(text: string, active: boolean): string {
  const [displayed, setDisplayed] = useState("");
  const rafRef = useRef<number | null>(null);
  const indexRef = useRef(0);

  useEffect(() => {
    if (!active || !text) { setDisplayed(text); return; }
    setDisplayed("");
    indexRef.current = 0;

    const tick = () => {
      indexRef.current += 6; // reveal ~6 chars per frame ≈ fast but visible
      setDisplayed(text.slice(0, indexRef.current));
      if (indexRef.current < text.length) {
        rafRef.current = requestAnimationFrame(tick);
      }
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [text, active]);

  return displayed;
}

export default function App() {
  const [view, setView] = useState<ViewId>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [form, setForm] = useState<StartupForm>(EMPTY_FORM);
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [results, setResults] = useState<ResultData[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [clearing, setClearing] = useState(false);
  const [healthData, setHealthData] = useState<HealthScoreResult | null>(null);
  const [investorData, setInvestorData] = useState<InvestorDecisionResult | null>(null);
  const [pitchData, setPitchData] = useState<PitchDeckResult | null>(null);

  // Typing-effect state — holds the latest raw output & triggers the hook
  const [latestOutput, setLatestOutput] = useState("");
  const [typingActive, setTypingActive] = useState(false);
  const typedOutput = useTypingEffect(latestOutput, typingActive);

  const sessionRef = useRef<string>(newSessionId());

  /* ---- Load history on mount ---- */
  const loadHistory = useCallback(async () => {
    try {
      const res = await fetch("/api/history");
      const data = await res.json();
      if (data.ok) setHistory(data.items as HistoryItem[]);
    } catch { /* ignore */ }
  }, []);

  useEffect(() => { loadHistory(); }, [loadHistory]);

  /* ---- Keyboard shortcut Ctrl/Cmd+Enter → generate ---- */
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
        if (view === "copilot" && !loading) {
          generate(GENERAL_AGENT.id);
        }
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view, loading, prompt, form]);

  /* ---- Core generation logic ---- */
  const generate = useCallback(
    async (agentId: string) => {
      setError(null);
      setSuccess(null);

      const hasContext =
        prompt.trim().length > 0 ||
        Object.values(form).some((v) => v && v.trim().length > 0);
      if (!hasContext) {
        setError("Please describe your startup or fill in the form before generating.");
        return;
      }

      setLoading(true);
      setTypingActive(false);
      try {
        const res = await fetch("/api/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ agentId, prompt, form, sessionId: sessionRef.current }),
        });
        const data = (await res.json()) as GenerateResponse;

        if (!res.ok || !data.ok) {
          setError(data.error || "Something went wrong. Please try again.");
          return;
        }

        const agent =
          data.agentId === "startup_health"
            ? HEALTH_SCORE_AGENT
            : data.agentId === "copilot"
            ? GENERAL_AGENT
            : AGENT_MAP[data.agentId] || GENERAL_AGENT;

        // Handle structured-output special agents
        if (data.agentId === "startup_health" && data.healthData) {
          setHealthData(data.healthData);
          setSuccess("Startup Health Score complete.");
          loadHistory();
          return;
        }
        if (data.agentId === "investor_decision" && data.investorData) {
          setInvestorData(data.investorData);
          setSuccess("Investor Decision Simulation complete.");
          loadHistory();
          return;
        }
        if (data.agentId === "pitch_deck" && data.pitchData) {
          setPitchData(data.pitchData);
          setSuccess("Pitch Deck generated.");
          loadHistory();
          return;
        }

        // trigger typing effect for the first (most recent) result
        setLatestOutput(data.output);
        setTypingActive(true);

        const result: ResultData = {
          id: `${Date.now()}`,
          agentId: data.agentId,
          agentName: data.agentName,
          agentIcon: agent.icon,
          title: data.title,
          output: data.output,
          mode: data.mode,
          form,
        };

        setResults((prev) => [result, ...prev]);
        setSuccess(`${data.agentName} report generated with IBM Granite.`);
        loadHistory();
      } catch {
        setError("Network error — please check your internet connection and try again.");
      } finally {
        setLoading(false);
      }
    },
    [prompt, form, loadHistory],
  );

  const handleQuickAction = useCallback(
    (agentId: string) => {
      setView("copilot");
      // defer so view renders before generate fires
      setTimeout(() => generate(agentId), 50);
    },
    [generate],
  );

  const handleInvestorPack = useCallback(async () => {
    setError(null);
    setSuccess(null);
    const hasContext =
      prompt.trim().length > 0 ||
      Object.values(form).some((v) => v && v.trim().length > 0);
    if (!hasContext) {
      setError("Please describe your startup or fill in the form before generating an Investor Pack.");
      return;
    }
    setLoading(true);
    setTypingActive(false);
    let completed = 0;
    try {
      for (const agentId of INVESTOR_PACK_AGENTS) {
        const agent = AGENT_MAP[agentId] || GENERAL_AGENT;
        setSuccess(`💼 Investor Pack: generating ${agent.name} (${completed + 1}/${INVESTOR_PACK_AGENTS.length})…`);
        const res = await fetch("/api/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            agentId,
            prompt: prompt || "Create an investor-ready startup report.",
            form,
            sessionId: sessionRef.current,
          }),
        });
        const data = (await res.json()) as GenerateResponse;
        if (!res.ok || !data.ok) { setError(data.error || `Could not generate ${agent.name}.`); return; }
        setResults((prev) => [{
          id: `${Date.now()}_${agentId}`,
          agentId: data.agentId,
          agentName: data.agentName,
          agentIcon: agent.icon,
          title: data.title,
          output: data.output,
          mode: data.mode,
          form,
        }, ...prev]);
        completed += 1;
      }
      setSuccess(`✅ Investor Pack complete — ${completed} IBM Granite reports generated.`);
      loadHistory();
    } catch {
      setError("Network error while generating the Investor Pack. Please try again.");
    } finally { setLoading(false); }
  }, [prompt, form, loadHistory]);

  const handleNewChat = useCallback(() => {
    sessionRef.current = newSessionId();
    setResults([]);
    setPrompt("");
    setForm(EMPTY_FORM);
    setError(null);
    setTypingActive(false);
    setSuccess("New session started. Fill in your startup profile and generate.");
  }, []);

  const handleClearHistory = useCallback(async () => {
    setClearing(true);
    try {
      await fetch("/api/history", { method: "DELETE" });
      setHistory([]);
      setResults([]);
      setSuccess("All history cleared.");
    } catch {
      setError("Could not clear history. Please try again.");
    } finally { setClearing(false); }
  }, []);

  const openHistoryItem = useCallback((item: HistoryItem) => {
    const agent = item.agentId === "copilot" ? GENERAL_AGENT : AGENT_MAP[item.agentId] || GENERAL_AGENT;
    setResults([{
      id: `h_${item.id}`,
      agentId: item.agentId,
      agentName: item.agentName,
      agentIcon: agent.icon,
      title: item.title,
      output: item.output,
      mode: "granite",
      form: EMPTY_FORM,
      isHistory: true,
    }]);
    setTypingActive(false);
    setView("copilot");
  }, []);

  const loadProject = useCallback((p: SavedProject) => {
    setForm(p.formData as unknown as StartupForm);
    setSuccess(`Project "${p.name}" loaded.`);
    setView("copilot");
  }, []);

  return (
    <div className="min-h-screen">
      <Sidebar
        active={view}
        onNavigate={setView}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onLoadHistoryItem={openHistoryItem}
        onLoadProject={loadProject}
        currentForm={form}
      />

      <div className="lg:pl-72">
        {/* Top bar */}
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-white/70 bg-white/70 px-4 py-3 shadow-sm backdrop-blur-xl lg:px-8">
          <button
            onClick={() => setSidebarOpen(true)}
            className="rounded-xl border border-slate-200 bg-white p-2 text-slate-600 shadow-sm lg:hidden"
            aria-label="Open menu"
          >
            ☰
          </button>
          <div className="flex items-center gap-2 lg:hidden">
            <span className="text-[15px] font-extrabold vf-gradient-text">VentureForge AI</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <span className="hidden rounded-full border border-indigo-100 bg-indigo-50 px-3 py-1 text-[11px] font-bold text-indigo-600 sm:inline-block">
              ⌨ Ctrl+Enter to generate
            </span>
            <button
              onClick={() => { handleNewChat(); setView("copilot"); }}
              className="vf-btn-gradient rounded-xl px-4 py-2 text-xs font-bold text-white"
            >
              ✦ New Blueprint
            </button>
          </div>
        </header>

        <main className="px-4 py-8 lg:px-8">
          {view === "dashboard" && (
            <Dashboard
              history={history}
              onNavigate={setView}
              onOpenHistory={openHistoryItem}
              onQuickAction={handleQuickAction}
            />
          )}
          {view === "copilot" && (
            <Copilot
              form={form}
              setForm={setForm}
              prompt={prompt}
              setPrompt={setPrompt}
              loading={loading}
              error={error}
              success={success}
              results={results}
              typedOutput={typedOutput}
              typingActive={typingActive}
              healthData={healthData}
              investorData={investorData}
              pitchData={pitchData}
              onGenerate={() => generate(GENERAL_AGENT.id)}
              onQuickAction={handleQuickAction}
              onInvestorPack={handleInvestorPack}
              onNewChat={handleNewChat}
              onClearHistory={handleClearHistory}
              clearing={clearing}
            />
          )}
          {view === "about" && <About />}
          {view === "settings" && (
            <Settings
              history={history}
              onClearHistory={handleClearHistory}
              clearing={clearing}
            />
          )}
        </main>
      </div>
    </div>
  );
}
