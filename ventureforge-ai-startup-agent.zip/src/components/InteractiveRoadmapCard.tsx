"use client";

import { useState } from "react";

export interface RoadmapPhase {
  phase: string;
  title: string;
  items: string[];
  color: string;
  icon: string;
}

interface Props { markdown: string; }

/**
 * Parses the roadmap agent's markdown into structured phases and renders
 * an interactive horizontal timeline with clickable milestones.
 */
export default function InteractiveRoadmapCard({ markdown }: Props) {
  const [active, setActive] = useState(0);

  // Parse phases from markdown — look for ## headers and bullet lists
  const phases: RoadmapPhase[] = [];
  const colors = [
    "from-violet-500 to-purple-600",
    "from-indigo-500 to-blue-500",
    "from-cyan-500 to-teal-500",
    "from-emerald-500 to-green-600",
    "from-amber-400 to-orange-500",
    "from-rose-400 to-pink-500",
  ];
  const icons = ["🌱","🔨","🚀","📈","🏆","💎"];

  let current: { title: string; items: string[] } | null = null;
  for (const line of markdown.split("\n")) {
    const hMatch = line.match(/^#{1,3}\s+(.+)/);
    if (hMatch) {
      if (current) phases.push({ phase: `Phase ${phases.length + 1}`, title: current.title, items: current.items, color: colors[phases.length % colors.length], icon: icons[phases.length % icons.length] });
      current = { title: hMatch[1].replace(/[*_`#]/g, "").trim(), items: [] };
    } else if (current) {
      const li = line.match(/^[\s\-*•]\s*(.+)/);
      if (li) current.items.push(li[1].replace(/\*\*(.+?)\*\*/g, "$1").replace(/^[0-9]+\.\s*/, "").trim());
    }
  }
  if (current) phases.push({ phase: `Phase ${phases.length + 1}`, title: current.title, items: current.items, color: colors[phases.length % colors.length], icon: icons[phases.length % icons.length] });

  // Keep last 6 meaningful phases max
  const expanded = phases.slice(0, 6);

  return (
    <article className="vf-card vf-fade-up overflow-hidden">
      <div className="flex flex-wrap items-center gap-3 border-b border-slate-100 px-6 py-4">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-orange-100 to-amber-100 text-xl">🗺️</span>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-extrabold text-slate-900">Interactive Startup Roadmap</div>
          <div className="text-xs text-slate-500">Click any phase to explore its milestones</div>
        </div>
        <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-[10px] font-bold uppercase text-emerald-700">IBM Granite</span>
      </div>

      <div className="p-6">
        {/* Horizontal timeline */}
        <div className="relative mb-6">
          {/* Track line */}
          <div className="absolute inset-y-[26px] left-0 right-0 h-1 rounded-full bg-slate-100" style={{ top: 26 }} />
          <div className="relative flex overflow-x-auto gap-0 pb-2">
            {expanded.map((p, i) => (
              <button
                key={i}
                onClick={() => setActive(i)}
                className="group relative flex flex-1 flex-col items-center min-w-[80px] pt-0"
              >
                <div
                  className={`relative z-10 flex items-center justify-center rounded-full border-4 text-xl shadow-md transition-all ${
                    i === active
                      ? `border-white bg-gradient-to-br ${p.color} scale-125 shadow-lg`
                      : "border-slate-100 bg-white hover:scale-110"
                  }`}
                  style={{ width: 52, height: 52 }}
                >
                  {p.icon}
                </div>
                <div className={`mt-2 rounded-full px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wide transition ${
                  i === active ? `bg-gradient-to-r ${p.color} text-white` : "bg-slate-100 text-slate-500"
                }`}>
                  {p.phase}
                </div>
                {i < expanded.length - 1 && (
                  <div className="absolute right-0 top-[26px] h-1 w-1/2 hidden" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Active phase content */}
        {expanded[active] && (
          <div className={`rounded-3xl bg-gradient-to-r p-0.5 ${expanded[active].color}`}>
            <div className="rounded-3xl bg-white p-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className={`text-[10px] font-extrabold uppercase tracking-widest bg-gradient-to-r ${expanded[active].color} bg-clip-text text-transparent`}>
                    {expanded[active].phase}
                  </p>
                  <h3 className="mt-1 text-xl font-extrabold text-slate-900">{expanded[active].title}</h3>
                </div>
                <span className="text-3xl">{expanded[active].icon}</span>
              </div>

              {/* Progress bar for the phase */}
              <div className="mt-4 flex items-center gap-2">
                <div className="flex-1 h-2 overflow-hidden rounded-full bg-slate-100">
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${expanded[active].color} transition-all duration-700`}
                    style={{ width: `${((active + 1) / expanded.length) * 100}%` }}
                  />
                </div>
                <span className="text-xs font-extrabold text-slate-500">
                  {active + 1}/{expanded.length}
                </span>
              </div>

              {/* Milestones */}
              <div className="mt-5 grid gap-2">
                {expanded[active].items.slice(0, 6).map((item, i) => (
                  <div key={i} className="flex items-start gap-3 rounded-xl bg-slate-50 px-4 py-3 transition hover:bg-slate-100">
                    <div className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gradient-to-br ${expanded[active].color} text-[9px] font-extrabold text-white`}>
                      {i + 1}
                    </div>
                    <p className="text-sm font-medium leading-5 text-slate-700">{item}</p>
                  </div>
                ))}
                {expanded[active].items.length === 0 && (
                  <p className="py-4 text-center text-sm text-slate-400">Open the report above for full details.</p>
                )}
              </div>

              {/* Prev / next */}
              <div className="mt-5 flex gap-2">
                <button
                  onClick={() => setActive(Math.max(0, active - 1))}
                  disabled={active === 0}
                  className="flex-1 rounded-xl border border-slate-200 py-2 text-sm font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-40"
                >
                  ← Prev Phase
                </button>
                <button
                  onClick={() => setActive(Math.min(expanded.length - 1, active + 1))}
                  disabled={active === expanded.length - 1}
                  className={`flex-1 rounded-xl bg-gradient-to-r ${expanded[active].color} py-2 text-sm font-bold text-white shadow-sm disabled:opacity-40`}
                >
                  Next Phase →
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </article>
  );
}
