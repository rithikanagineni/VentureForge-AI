"use client";

import type { InvestorDecisionResult } from "@/lib/types";

const verdictStyle: Record<string, { bg: string; text: string; badge: string }> = {
  Invest: { bg: "bg-emerald-50 border-emerald-200", text: "text-emerald-800", badge: "bg-emerald-500" },
  Pass: { bg: "bg-rose-50 border-rose-200", text: "text-rose-800", badge: "bg-rose-500" },
  Conditional: { bg: "bg-amber-50 border-amber-200", text: "text-amber-800", badge: "bg-amber-500" },
  Watch: { bg: "bg-slate-50 border-slate-200", text: "text-slate-700", badge: "bg-slate-400" },
};

function ConvictionDots({ score }: { score: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 10 }, (_, i) => (
        <div key={i} className={`h-1.5 w-1.5 rounded-full ${i < score ? "bg-indigo-500" : "bg-slate-200"}`} />
      ))}
    </div>
  );
}

const typeColor: Record<string, string> = {
  "Angel": "from-yellow-400 to-orange-400",
  "Seed VC": "from-indigo-500 to-violet-500",
  "Series A VC": "from-fuchsia-500 to-pink-500",
};

export default function InvestorDecisionCard({ result }: { result: InvestorDecisionResult }) {
  const overall = verdictStyle[result.overall_verdict] || verdictStyle.Watch;

  return (
    <article className="vf-card vf-fade-up overflow-hidden">
      <div className="flex flex-wrap items-center gap-3 border-b border-slate-100 px-6 py-4">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-lime-100 to-green-100 text-xl">💼</span>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-extrabold text-slate-900">Investor Decision Simulator</div>
          <div className="text-xs text-slate-500">3 investor profiles · IBM Granite</div>
        </div>
        <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-[10px] font-bold uppercase text-emerald-700">IBM Granite</span>
      </div>

      <div className="px-6 py-6">
        {/* Overall verdict banner */}
        <div className={`flex flex-wrap items-center justify-between gap-4 rounded-2xl border p-5 ${overall.bg} mb-6`}>
          <div>
            <p className="text-xs font-bold uppercase tracking-widest" style={{ opacity: .6 }}>Overall Verdict</p>
            <div className={`mt-1 text-3xl font-extrabold ${overall.text}`}>{result.overall_verdict}</div>
          </div>
          <div className="text-right">
            <div className="text-4xl font-extrabold" style={{ color: result.readiness_score >= 70 ? "#10b981" : result.readiness_score >= 50 ? "#f59e0b" : "#f43f5e" }}>
              {result.readiness_score}
            </div>
            <div className="text-xs font-bold text-slate-500">readiness score</div>
          </div>
        </div>

        {/* Per-investor cards */}
        <div className="grid grid-cols-1 gap-4">
          {result.investors.map((inv, i) => {
            const vs = verdictStyle[inv.verdict] || verdictStyle.Watch;
            return (
              <div key={i} className={`rounded-2xl border p-5 ${vs.bg}`}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br text-lg font-extrabold text-white ${typeColor[inv.type] || "from-slate-400 to-slate-600"}`}>
                      {inv.type?.[0] || "I"}
                    </div>
                    <div>
                      <div className="text-sm font-extrabold text-slate-800">{inv.name}</div>
                      <div className="text-xs text-slate-500">{inv.type}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className={`inline-block rounded-full px-3 py-1 text-xs font-extrabold text-white ${vs.badge}`}>
                        {inv.verdict}
                      </div>
                      <div className="mt-1 text-xs font-bold text-slate-500">{inv.amount}</div>
                    </div>
                    <div>
                      <div className="mb-0.5 text-right text-[10px] text-slate-500">Conviction</div>
                      <ConvictionDots score={inv.conviction} />
                    </div>
                  </div>
                </div>
                <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <p className="mb-1 text-[10px] font-bold uppercase tracking-wide" style={{ opacity: .6 }}>What they loved</p>
                    <p className="text-xs leading-5 text-slate-700">{inv.what_they_loved}</p>
                  </div>
                  <div>
                    <p className="mb-1 text-[10px] font-bold uppercase tracking-wide" style={{ opacity: .6 }}>Their concern</p>
                    <p className="text-xs leading-5 text-slate-700">{inv.their_concern}</p>
                  </div>
                </div>
                <div className="mt-3">
                  <p className="mb-2 text-[10px] font-bold uppercase tracking-wide" style={{ opacity: .6 }}>Questions they asked</p>
                  <div className="space-y-1">
                    {inv.questions_they_ask.map((q, j) => (
                      <div key={j} className="flex items-start gap-2">
                        <span className="mt-0.5 text-[10px] inline-block rounded-full px-1.5 py-0.5 font-extrabold text-white" style={{ background: "linear-gradient(90deg,#6366f1,#a855f7)" }}>Q{j+1}</span>
                        <p className="text-xs text-slate-700 leading-5">{q}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Summary */}
        <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
          {[
            { label: "🌟 Lead with", value: result.top_strength_to_mention, bg: "bg-emerald-50 border-emerald-200" },
            { label: "⚠️ Fix first", value: result.biggest_risk_to_address, bg: "bg-rose-50 border-rose-200" },
            { label: "🎯 Next step", value: result.best_next_step, bg: "bg-indigo-50 border-indigo-200" },
          ].map(({ label, value, bg }) => (
            <div key={label} className={`rounded-2xl border p-4 ${bg}`}>
              <p className="mb-1.5 text-xs font-extrabold">{label}</p>
              <p className="text-xs leading-5 text-slate-600">{value}</p>
            </div>
          ))}
        </div>
      </div>
    </article>
  );
}
