/** Structured startup context collected from the home page form. */
export interface StartupForm {
  startupName: string;
  industry: string;
  country: string;
  budget: string;
  stage: string;
  targetCustomers: string;
  problem: string;
  description: string;
}

export const EMPTY_FORM: StartupForm = {
  startupName: "",
  industry: "",
  country: "",
  budget: "",
  stage: "",
  targetCustomers: "",
  problem: "",
  description: "",
};

/** Payload sent to /api/generate. */
export interface GenerateRequest {
  agentId: string;
  prompt: string;
  form: StartupForm;
  sessionId: string;
}

/** Response returned by /api/generate. */
export interface GenerateResponse {
  ok: boolean;
  output: string;
  agentId: string;
  agentName: string;
  title: string;
  mode: "granite";
  error?: string;
  /** Populated only for the Startup Health Score agent. */
  healthData?: HealthScoreResult;
  /** Populated only for the Investor Decision Simulator. */
  investorData?: InvestorDecisionResult;
  /** Populated only for the Pitch Deck Generator. */
  pitchData?: PitchDeckResult;
}

/** A saved history record shown in the sidebar / dashboard. */
export interface HistoryItem {
  id: number;
  sessionId: string;
  agentId: string;
  agentName: string;
  title: string;
  prompt: string;
  output: string;
  mode: string;
  createdAt: string;
}

/** Dimensions returned by the Startup Health Score agent. */
export interface HealthDimension {
  name: string;
  score: number;
  note: string;
}
export interface HealthScoreResult {
  overall_score: number;
  grade: string;
  summary: string;
  dimensions: HealthDimension[];
  top_strengths: string[];
  critical_risks: string[];
  next_actions: string[];
}

/** Response from the Investor Decision Simulator. */
export interface InvestorProfile {
  name: string;
  type: "Angel" | "Seed VC" | "Series A VC";
  verdict: "Invest" | "Pass" | "Conditional";
  amount: string;
  conviction: number;
  what_they_loved: string;
  their_concern: string;
  questions_they_ask: string[];
}
export interface InvestorDecisionResult {
  overall_verdict: "Invest" | "Pass" | "Conditional" | "Watch";
  readiness_score: number;
  investors: InvestorProfile[];
  top_strength_to_mention: string;
  biggest_risk_to_address: string;
  best_next_step: string;
}

/** Response from the Pitch Deck Generator. */
export interface PitchSlide {
  number: number;
  title: string;
  content: string[];
  speaker_notes: string;
  visual_suggestion: string;
}
export interface PitchDeckResult {
  tagline: string;
  deck_title: string;
  slides: PitchSlide[];
}

/** A saved startup project profile. */
export interface SavedProject {
  id: number;
  name: string;
  formData: Record<string, string>;
  isPinned: boolean;
  createdAt: string;
  updatedAt: string;
}
