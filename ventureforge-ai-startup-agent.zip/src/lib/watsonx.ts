import type { Agent } from "./agents";
import type { StartupForm } from "./types";

/** IBM watsonx.ai integration using an IBM Granite foundation model. */
const IAM_URL = "https://iam.cloud.ibm.com/identity/token";
const DEFAULT_URL = "https://us-south.ml.cloud.ibm.com";
const DEFAULT_MODEL = "ibm/granite-3-8b-instruct";

interface TokenCache {
  token: string;
  expiresAt: number;
}

let tokenCache: TokenCache | null = null;

export function graniteConfigured(): boolean {
  return Boolean(process.env.WATSONX_API_KEY && process.env.WATSONX_PROJECT_ID);
}

async function getIamToken(apiKey: string): Promise<string> {
  const now = Date.now();
  if (tokenCache && tokenCache.expiresAt > now + 60_000) return tokenCache.token;

  const res = await fetch(IAM_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
    },
    body: new URLSearchParams({
      grant_type: "urn:ibm:params:oauth:grant-type:apikey",
      apikey: apiKey,
    }),
  });

  if (!res.ok) {
    throw new Error(`IBM IAM authentication failed (${res.status}). Check your API key.`);
  }

  const data = (await res.json()) as { access_token: string; expires_in: number };
  tokenCache = {
    token: data.access_token,
    expiresAt: now + data.expires_in * 1000,
  };
  return data.access_token;
}

export interface GenerationResult {
  text: string;
  mode: "granite";
}

async function callGranite(prompt: string): Promise<string> {
  const apiKey = process.env.WATSONX_API_KEY as string;
  const projectId = process.env.WATSONX_PROJECT_ID as string;
  const baseUrl = process.env.WATSONX_URL || DEFAULT_URL;
  const modelId = process.env.WATSONX_MODEL_ID || DEFAULT_MODEL;
  const token = await getIamToken(apiKey);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 45_000);

  try {
    const res = await fetch(`${baseUrl}/ml/v1/text/generation?version=2024-05-31`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      signal: controller.signal,
      body: JSON.stringify({
        model_id: modelId,
        project_id: projectId,
        input: prompt,
        parameters: {
          decoding_method: "greedy",
          max_new_tokens: 1800,
          min_new_tokens: 200,
          repetition_penalty: 1.05,
        },
      }),
    });

    if (!res.ok) {
      const detail = await res.text().catch(() => "");
      throw new Error(`IBM Granite API error (${res.status}). ${detail.slice(0, 200)}`);
    }

    const data = (await res.json()) as {
      results?: Array<{ generated_text?: string }>;
    };
    const text = data.results?.[0]?.generated_text?.trim();
    if (!text) throw new Error("IBM Granite returned an empty response.");
    return text;
  } finally {
    clearTimeout(timeout);
  }
}

/** Generate a report exclusively through IBM Granite. */
export async function generateBlueprint(
  _agent: Agent,
  _prompt: string,
  _form: StartupForm,
  fullPrompt: string,
): Promise<GenerationResult> {
  if (!graniteConfigured()) {
    throw new Error(
      "IBM Granite is not configured. Add WATSONX_API_KEY and WATSONX_PROJECT_ID to the server environment, then try again.",
    );
  }

  try {
    return { text: await callGranite(fullPrompt), mode: "granite" };
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") {
      throw new Error("IBM Granite timed out. Please try again in a moment.");
    }
    throw error;
  }
}
