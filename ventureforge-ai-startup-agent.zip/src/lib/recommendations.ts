import type { HistoryItem } from "./types";

export type RecCategory = "action" | "warning" | "tip" | "milestone";

export interface Recommendation {
  category: RecCategory;
  text: string;
  icon: string;
}

/**
 * Analyses the generated report history and returns personalised next-step
 * suggestions for the founder — without any additional AI API calls.
 */
export function buildRecommendations(history: HistoryItem[]): Recommendation[] {
  const recs: Recommendation[] = [];
  const has = (id: string) => history.some((h) => h.agentId === id);
  const mark = (cond: boolean, r: () => void) => { if (cond) r(); };

  if (history.length === 0) {
    recs.push(
      { category: "action", icon: "🚀", text: "Fill in your Startup Profile and generate your first blueprint with IBM Granite." },
      { category: "tip",   icon: "📋", text: "Start with the Business Plan agent — it anchors every other report." },
      { category: "tip",   icon: "🔍", text: "Run Idea Validation before writing any code to de-risk the venture." },
    );
    return recs;
  }

  // Recommended next steps depending on gaps
  if (!has("idea_validation")) {
    recs.push({ category: "action", icon: "🔍", text: "Run the Idea Validation agent before pitching or building further." });
  }
  if (!has("business_plan")) {
    recs.push({ category: "action", icon: "📋", text: "Generate a full Business Plan — the foundational document for investor meetings." });
  }
  if (!has("market_research")) {
    recs.push({ category: "action", icon: "📊", text: "Complete Market Research to size your TAM/SAM/SOM with IBM Granite." });
  }
  if (!has("competitor_analysis")) {
    recs.push({ category: "action", icon: "⚔️", text: "Analyse competitors to sharpen your differentiation and positioning." });
  }
  if (!has("revenue_model")) {
    recs.push({ category: "action", icon: "📈", text: "Design your Revenue Model with pricing tiers and unit economics." });
  }
  if (!has("funding")) {
    recs.push({ category: "tip", icon: "💰", text: "Generate a Funding Strategy to identify suitable grants, angels and VC paths." });
  }
  if (!has("roadmap")) {
    recs.push({ category: "tip", icon: "🗺️", text: "Build your Execution Roadmap to communicate milestones to co-founders and investors." });
  }
  if (!has("startup_health")) {
    recs.push({ category: "tip", icon: "🏥", text: "Run the Startup Health Score to measure all 8 readiness dimensions out of 100." });
  }
  if (!has("business_model_canvas")) {
    recs.push({ category: "tip", icon: "🧩", text: "Generate a Business Model Canvas for a one-page summary investors love." });
  }
  if (!has("legal_compliance")) {
    recs.push({ category: "warning", icon: "⚖️", text: "Check Legal & Compliance — registration, IP protection, and government schemes." });
  }

  // Milestone celebrations
  mark(has("investor_pitch"), () =>
    recs.push({ category: "milestone", icon: "🎤", text: "Investor Pitch generated! Export it as PDF and rehearse your delivery." })
  );
  mark(has("investor_pitch") && has("funding") && has("business_plan"), () =>
    recs.push({ category: "milestone", icon: "🏆", text: "You have a complete Investor Pack — you're ready to approach investors." })
  );
  mark(has("swot") && has("competitor_analysis"), () =>
    recs.push({ category: "milestone", icon: "🧭", text: "SWOT + Competitor Analysis complete. You now know your strategic position." })
  );
  mark(has("business_model_canvas") && has("revenue_model"), () =>
    recs.push({ category: "milestone", icon: "💡", text: "Business model fully mapped. Export as Markdown to share with co-founders." })
  );

  return recs.slice(0, 6);
}

/** Group history by calendar-day for a bar chart of report activity. */
export function buildActivityChart(history: HistoryItem[]): { day: string; count: number }[] {
  const days: Record<string, number> = {};
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toLocaleDateString("en-US", { weekday: "short" });
    days[key] = 0;
  }
  for (const h of history) {
    const key = new Date(h.createdAt).toLocaleDateString("en-US", { weekday: "short" });
    if (days[key] !== undefined) days[key] += 1;
  }
  return Object.entries(days).map(([day, count]) => ({ day, count }));
}

/** Breakdown of reports per agent for a horizontal chart. */
export function buildAgentBreakdown(
  history: HistoryItem[],
): { name: string; count: number; pct: number }[] {
  const map: Record<string, number> = {};
  for (const h of history) {
    map[h.agentName] = (map[h.agentName] || 0) + 1;
  }
  const max = Math.max(...Object.values(map), 1);
  return Object.entries(map)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([name, count]) => ({ name: name.replace(" Agent", ""), count, pct: Math.round((count / max) * 100) }));
}